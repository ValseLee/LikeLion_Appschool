//
//  networkTestApp.swift
//  networkTest
//
//  Created by 이승준 on 2022/11/22.
//

import SwiftUI

@main
struct networkTestApp: App {
    var body: some Scene {
        WindowGroup {
            MainHomeView()
        }
    }
}
